# ZIZTEC

Aplicativo leve para criação de músicas por inteligência artificial.

## Funções
- Campo de letra sem limite artificial de caracteres.
- Campo para qualquer estilo musical.
- Título da música.
- Biblioteca interna para guardar projetos e áudios gerados.
- Reprodução dos áudios guardados.
- Download do áudio para o telefone.
- Exclusão de projetos guardados.
- Estrutura preparada para geração real através de um backend seguro em `/api/music/generate`.

## Segurança
A chave secreta do serviço de inteligência artificial não deve ser colocada no aplicativo. Ela deve ficar somente no backend.

## Observação
A interface e o armazenamento local estão implementados. A geração real de áudio depende de um backend autorizado ligado a um serviço de geração de música por inteligência artificial.
