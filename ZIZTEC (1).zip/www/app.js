const API_URL = "/api/music/generate";
const DB_NAME = "ZIZTEC_DB";
const STORE = "songs";

const $ = id => document.getElementById(id);
let currentAudioBlob = null;
let currentAudioUrl = null;

document.querySelectorAll(".tab").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.tab).classList.add("active");
    if (btn.dataset.tab === "library") renderLibrary();
  });
});

$("lyrics").addEventListener("input", () => {
  $("counter").textContent = `${$("lyrics").value.length.toLocaleString("pt-PT")} caracteres`;
});

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function saveSong(song) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(song);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getSongs() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE, "readonly").objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result.sort((a,b) => b.createdAt - a.createdAt));
    req.onerror = () => reject(req.error);
  });
}

async function deleteSong(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

$("generate").addEventListener("click", async () => {
  const title = $("title").value.trim();
  const style = $("style").value.trim();
  const lyrics = $("lyrics").value;

  if (!title || !style || !lyrics.trim()) {
    $("status").textContent = "Preencha o título, o estilo musical e a letra.";
    return;
  }

  $("generate").disabled = true;
  $("status").textContent = "A gerar a música...";
  $("current").classList.add("hidden");
  currentAudioBlob = null;

  try {
    const form = new FormData();
    form.append("title", title);
    form.append("style", style);
    form.append("lyrics", lyrics);

    const response = await fetch(API_URL, { method: "POST", body: form });
    if (!response.ok) throw new Error("Falha no servidor.");

    const type = response.headers.get("content-type") || "";
    if (type.includes("audio/")) {
      currentAudioBlob = await response.blob();
    } else {
      const data = await response.json();
      if (!data.audioUrl) throw new Error("Áudio não recebido.");
      const audioResponse = await fetch(data.audioUrl);
      currentAudioBlob = await audioResponse.blob();
    }

    if (currentAudioUrl) URL.revokeObjectURL(currentAudioUrl);
    currentAudioUrl = URL.createObjectURL(currentAudioBlob);
    $("player").src = currentAudioUrl;
    $("current").classList.remove("hidden");
    $("status").textContent = "Música criada com sucesso.";
  } catch (error) {
    $("status").textContent = "A geração real ainda precisa de um backend ligado ao serviço de inteligência artificial.";
  } finally {
    $("generate").disabled = false;
  }
});

$("save").addEventListener("click", async () => {
  if (!currentAudioBlob) return;
  const song = {
    id: crypto.randomUUID(),
    title: $("title").value.trim(),
    style: $("style").value.trim(),
    lyrics: $("lyrics").value,
    createdAt: Date.now(),
    audioBlob: currentAudioBlob
  };
  await saveSong(song);
  $("status").textContent = "Música guardada na biblioteca.";
});

$("downloadCurrent").addEventListener("click", () => {
  if (!currentAudioBlob) return;
  const name = (($("title").value.trim() || "ziztec-musica").replace(/[^a-z0-9À-ÿ _-]/gi, "_")) + ".mp3";
  downloadBlob(currentAudioBlob, name);
});

async function renderLibrary() {
  const list = $("libraryList");
  const empty = $("empty");
  list.innerHTML = "";
  const songs = await getSongs();
  empty.style.display = songs.length ? "none" : "block";

  for (const song of songs) {
    const item = document.createElement("div");
    item.className = "item";
    const url = URL.createObjectURL(song.audioBlob);
    item.innerHTML = `
      <h3></h3>
      <p></p>
      <p></p>
      <audio controls></audio>
      <div class="actions">
        <button class="download">Baixar</button>
        <button class="delete">Excluir</button>
      </div>`;
    item.querySelector("h3").textContent = song.title;
    item.querySelectorAll("p")[0].textContent = `Estilo: ${song.style}`;
    item.querySelectorAll("p")[1].textContent = `Letra: ${song.lyrics.length.toLocaleString("pt-PT")} caracteres`;
    item.querySelector("audio").src = url;
    item.querySelector(".download").onclick = () => downloadBlob(song.audioBlob, `${song.title || "ziztec-musica"}.mp3`);
    item.querySelector(".delete").onclick = async () => {
      await deleteSong(song.id);
      URL.revokeObjectURL(url);
      renderLibrary();
    };
    list.appendChild(item);
  }
}

renderLibrary();
